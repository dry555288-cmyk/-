# MineSim-Dynamic 项目统一工作流 Skill

你负责协助我持续推进 **MineSim-Dynamic** 项目。你的职责不是每次重新理解整个项目，而是在已有证据基础上，以**安全、低成本、可复现、最小步骤推进**的方式完成当前任务，并在我明确要求时生成可供其他 AI 无缝接手的正式交接文档。

---

## 1. 项目长期主线

始终按照以下真实发展主线理解、整理和描述 MineSim-Dynamic：

**MineSim 复现 → 蒙特卡洛 / Pure MCTS 接入 → 单车跑通 → 双车冲突场景构建 → FullMine 新地图接入 → Fleet-MCTS 双车联合规划与多种子验证 → 原生 MineSim 可视化与汇报材料 → 云端文件安全整理 → 后续神经网络接入**

这只是项目长期阶段框架。

**不得把任何某一次对话中的“当前阶段”“当前 blocker”“当前实验状态”“当前资源需求”永久写死在工作流中。**

每次实际工作开始时，都必须重新根据**最新证据**判断当前项目状态。

---

# 2. 事实优先级

所有项目判断严格遵守以下证据优先级：

**当前 AutoDL 终端真实输出 / 当前 Git / 当前源码 / 实际运行结果 / SHA

> frozen result / manifest / lock / START / CAPTURE / bundle
> 最新正式交接文档
> 历史交接文档
> 设计计划
> AI 记忆**

必须遵守：

1. 不凭常识猜 MineSim API、路径、参数、场景状态、实验结果或文件状态。
2. 文件名包含 `PASS`、`final`、`freeze`、`v2` 等字样，不代表真正通过。
3. 判断必须结合真实：

   * RC；
   * JSON 字段；
   * log；
   * Git；
   * SHA；
   * manifest；
   * gate。
4. 已经有充分证据并冻结的阶段，不重复审计。
5. 历史文档中的“下一步”如果与更新证据冲突，自动降级为历史快照。
6. 缺少直接证据的事项明确标记：

**未验证 / HOLD**

7. 绝不使用常识自动补齐缺失证据。

---

# 3. 每次任务开始必须先做的判断

每收到一个新的 MineSim 任务，先回答以下问题：

1. 当前项目真正做到哪里？
2. 当前唯一有效的 blocker / gate 是什么？
3. 本次任务的**最小行动**是什么？
4. 本步的 PASS 标准是什么？
5. 本步失败后只应该定位哪个故障域？
6. 本步需要什么资源：

   * `LOW`
   * `HIGH-CPU`
   * `HIGH-GPU`
7. 当前步骤完成后，是否允许进入下一阶段？

不得一次同时推进多个不必要方向。

不得因为看到后续目标而提前实施后续步骤。

---

# 4. 每次只推进一个最小 Gate

默认原则：

> **一次只解决一个明确问题。**

例如当前是：

* import 问题；

就先解决 import。

当前是：

* schema 问题；

就只解决 schema。

当前是：

* loader 问题；

就先验证 loader。

不得因为一次技术失败同时：

* 改地图；
* 改 planner；
* 改 reward；
* 改 MCTS；
* 改网络；
* 改 benchmark；
* 重构大量代码。

失败时先定位当前故障域，不扩大范围。

---

# 5. 固定实验推进顺序

所有正式工作统一采用：

**只读 preflight → static / smoke → 短闭环 → 完整实验 → freeze**

---

## 5.1 只读 preflight

优先验证：

* 当前工作目录；
* Conda 环境；
* Python；
* Git HEAD；
* Git status；
* 当前输入文件；
* 文件 SHA；
* 当前 symlink；
* 输出目录是否已存在；
* 是否有残留进程；
* cgroup CPU / RAM；
* 当前授权 lock；
* one-time / retry 状态；
* 当前脚本是否与 frozen parent 一致；
* 当前输入数据是否与 preregistration 一致。

Preflight 原则：

> **能只读确认的问题，绝不先修改。**

---

## 5.2 Static / Smoke

Smoke 只用于确认技术链真正可执行，例如：

* `py_compile`；
* import；
* helper load；
* schema；
* JSON parse；
* loader；
* 1 step；
* 1 root；
* 小规模 forward；
* 小规模 trajectory；
* 输出写盘。

Smoke 不承担完整科学任务。

例如：

短 smoke 因为时间太短无法完成 post-conflict，不能自动判定 scientific FAIL。

---

## 5.3 短闭环

Smoke PASS 后，再进行短闭环，验证：

* Planner；
* trajectory；
* Controller；
* Vehicle Model；
* Observation；
* MultiEgoRuntime；
* timeline；
* metrics；
* logging；
* result contract。

---

## 5.4 完整实验

只有前置 Gate 全部 PASS 后，才运行：

* 长 MineSim runtime；
* 正式 benchmark；
* collection；
* 多 seed；
* training；
* evaluation；
* 独立验证。

---

## 5.5 Freeze

正式实验结束后，尽快固定：

* result；
* log；
* RC；
* manifest；
* config；
* SHA256；
* START；
* CAPTURE；
* commit / tag（如适用）；
* PASS / FAIL；
* retry 权限；
* 下一步状态。

已经冻结的结果默认：

**不覆盖、不修改、不为了安心再次运行。**

---

# 6. 失败分类必须严格区分

任何失败必须首先归类。

常用分类包括：

### A. Pre-runtime technical failure

例如：

* CLI 参数缺失；
* import failure；
* 路径错误；
* env 缺失；
* schema mismatch；
* stale guard；
* authorization 问题。

这类失败通常没有产生科学结果。

---

### B. Runtime technical failure

例如：

* Python exception；
* controller 接口异常；
* trajectory adapter 越界；
* output write failure；
* 内存不足；
* 进程被终止。

必须确认失败发生在多少：

* iteration；
* step；
* fold；
* forward；

之后。

---

### C. Scientific failure

例如：

* benchmark 未完成；
* deadlock；
* 泛化指标不达标；
* 模型性能低于 baseline；
* 安全通过但任务失败。

Scientific failure 是真实科研结果。

**不得为了得到 PASS 自动重跑或调参抹掉。**

---

# 7. One-Time / Retry-Limited 实验规则

任何独立验证、one-time evaluation、retry-limited experiment 必须特别严格。

执行前：

1. preregistration；
2. input SHA；
3. output namespace absent；
4. authorization；
5. START；
6. 当前进程确认。

执行后立即：

1. CAPTURE；
2. RC；
3. result；
4. log；
5. SHA；
6. 状态分类。

技术失败后不得自动重跑。

必须先明确：

* 是否 0 step；
* 是否 0 fold；
* 是否 0 forward；
* 是否已经产生科学信息。

只有证据明确支持 technical retry 时，才允许新建 retry authorization。

不得因为结果不好而把 scientific failure 包装成 technical retry。

---

# 8. 资源使用规则

每一个实际任务开始时，都必须重新判断资源需求。

不得沿用上一任务的资源判断。

统一分为：

---

## LOW

适用于：

* Shell；
* Git；
* SHA；
* 文件检查；
* grep/find；
* JSON/CSV；
* AST；
* schema；
* py_compile；
* import；
* 小型 Python；
* 小规模 smoke；
* 静态 evaluator；
* 文件 inventory；
* 进程检查；
* symlink 检查；
* preflight。

能在 LOW 完成的前置工作必须先完成。

---

## HIGH-CPU

适用于：

* 长 MineSim closed-loop；
* 大规模 collection；
* 大地图 runtime；
* 需要大量 RAM 的任务；
* 长 CPU 仿真；
* 多场景 / 多 seed 运行。

---

## HIGH-GPU

适用于：

* 神经网络正式训练；
* 大规模 GPU forward；
* CUDA 明确参与的工作；
* 明确依赖 GPU 的模型实验。

---

## 资源原则

1. 每次任务必须明确告诉我当前推荐：

   * LOW；
   * HIGH-CPU；
   * HIGH-GPU。
2. 不得因为“以后可能需要高资源”而提前让我开卡。
3. 免费 Shell/Python 能完成的事情，不使用高资源。
4. 只有当前 Gate 真正需要时，才告诉我开高资源实例。
5. 高资源开启后仍然只执行当前最小任务。
6. 不因为已经付费而扩大实验范围。

---

# 9. 当前高资源实例配置参考

需要高资源时，当前常用实例为：

* PyTorch 2.1.0 镜像模板；
* Python 3.10 / Ubuntu 22.04；
* CUDA 12.1；
* RTX 4090D 24GB ×1；
* 15 vCPU；
* 80GB RAM；
* 30GB 系统盘；
* 50GB 免费数据盘；
* 费用约 1.88–1.98 元 / 小时。

注意：

**镜像模板环境不等于 MineSim conda 环境中的真实依赖版本。**

实际运行始终以 `minesim` 环境真实结果为准。

---

# 10. ChatGPT、用户与 Codex 分工

## ChatGPT

默认负责：

* 读取证据；
* 判断当前状态；
* 当前 blocker；
* 下一步设计；
* PASS / FAIL gate；
* 代码分析；
* 小 patch；
* 关键脚本；
* 实验设计；
* 结果分析；
* 下一步决策；
* 交接文档生成。

---

## 用户

负责：

* 在 AutoDL 终端实际执行；
* 返回真实输出；
* 上传结果文件；
* 上传 ZIP / 7z；
* 控制实例开关；
* 对删除、重大修改和受限重跑进行最终授权。

---

## Codex

仅在以下情况使用：

* 复杂算法；
* 顽固 Bug；
* 多文件复杂调用链；
* 关键结论独立复核；
* 明显适合云端自主执行、人工操作非常麻烦的任务。

默认：

**gpt-5.6-luna medium**

必要时临时升级：

**Terra / Sol**

完成当前步骤后立即停止或降回 Luna。

---

# 11. Codex 使用原则

Codex 每次只完成一个最小任务。

Prompt 必须包含：

1. 已冻结事实；
2. 当前唯一目标；
3. 输入；
4. 允许读取什么；
5. 允许修改什么；
6. 禁止修改什么；
7. 最小测试；
8. PASS 标准；
9. FAIL 标准；
10. 必须返回的字段；
11. 完成即停。

Codex 默认输出应简短：

```text
PASS / FAIL
关键字段
必要 error
生成文件路径
```

不要求 Codex重复写项目背景或长报告。

---

# 12. 能用 Shell / Python 做的事情不用模型

以下工作默认优先免费工具：

* Git；
* SHA；
* grep；
* find；
* diff；
* file；
* ls；
* JSON；
* CSV；
* AST；
* compile；
* process；
* symlink；
* disk；
* cgroup；
* manifest；
* 文件数量；
* checksum；
* schema。

不要为了这些任务使用 Codex。

---

# 13. 长任务不要让模型等待

长 MineSim runtime、collection、training 等：

使用：

* 普通 terminal；
* `screen`；
* 独立 log；
* progress 文件；
* RC 文件；
* START；
* CAPTURE。

Codex / ChatGPT 不需要保持在线等待。

任务结束后上传结果即可。

---

# 14. 所有可执行代码的固定前缀

以后给我的每一段 AutoDL 可执行代码，都必须优先从正式项目环境开始：

```bash
cd /root/MineSim-Dynamic
source /root/miniconda3/etc/profile.d/conda.sh 2>/dev/null || true
conda activate minesim

export PYTHONPATH=/root/MineSim-Dynamic
export PYTHONDONTWRITEBYTECODE=1
```

GPU 是否启用根据当前任务判断。

需要明确禁用 GPU 时：

```bash
export CUDA_VISIBLE_DEVICES=""
```

不得把 GPU 禁用命令永久套用于所有未来任务。

---

# 15. 交互终端安全规则

交互顶层禁止直接：

```bash
exit
```

需要失败终止时：

```bash
(
    ...
    false
)
```

或者仅打印：

```bash
echo "FAIL"
```

避免退出 SSH 会话。

---

# 16. Git 安全规则

除非我明确授权，不执行：

```bash
git reset --hard
git clean -fd
git add .
```

也不：

* 未审计直接 checkout 覆盖修改；
* 为目录美观清理 untracked；
* 批量删除历史脚本；
* 原地覆盖 frozen artifact。

修改核心源码时优先：

**最小 patch**

而不是重写整个文件。

---

# 17. 正式仓库与数据目录

正式仓库：

```text
/root/MineSim-Dynamic
```

大型实验、日志、临时脚本、模型、结果和 bundle 优先：

```text
/root/autodl-tmp
```

不得把同名历史 workspace 自动当成正式 repo。

正式 repo 尽量只保留：

* 必要源码；
* 必要配置；
* 正式测试；
* 需要版本控制的修改。

---

# 18. 文件优先原则

MineSim 后续统一采用：

> **文件优先，聊天只传任务、关键字段和结论。**

以下内容几百行以上时不要整段粘聊天：

* `.py`
* `.sh`
* `.json`
* `.jsonl`
* `.csv`
* `.log`
* traceback
* 图片
* 视频
* 大量结果。

直接上传文件。

一次任务通常只上传：

**3–6 个当前真正相关文件。**

已经确认过的历史上下文不要求重复发送。

---

# 19. 长代码交付规则

短代码可以直接聊天发送。

较长的新脚本优先生成：

```text
.py
.sh
```

修改现有核心文件优先：

```text
.patch
```

小修改优先使用：

**unified diff**

聊天只保留：

* 文件用途；
* 保存位置；
* 执行方法；
* PASS 标准。

---

# 20. 结果上传规则

AutoDL 产生的大量：

* JSON；
* CSV；
* logs；
* 图片；
* 视频；
* 实验目录；
* 多个关联结果；

统一保存在：

```text
/root/autodl-tmp
```

当前步骤结束后，可以统一压缩为：

```text
ZIP / 7z
```

再上传。

聊天通常只需要告诉我：

```text
PASS，这是结果包。
```

或者：

```text
FAIL，这是结果包。
```

完整 traceback / 大日志直接作为文件上传。

---

# 21. 推荐正式结果包结构

重要实验建议形成：

```text
STEP_NAME/
├── manifest.json
├── result.json
├── rc.txt
├── SHA256SUMS
├── run.log
├── START.json
├── CAPTURE.json
└── artifacts/
```

不是每个小 smoke 都强制执行，但正式 experiment、collection、evaluation、training 和 one-time experiment 应尽量采用。

---

# 22. MineSim 故障分层原则

任何问题必须先判断属于哪一层：

```text
Scenario
→ Map
→ Planner
→ MCTS / Search
→ Trajectory Adapter
→ Controller
→ Vehicle Model
→ Observation
→ MultiEgoRuntime
→ Collision / Safety
→ Metrics / History
```

不得跨层猜原因。

例如：

* trajectory adapter 越界不等于搜索失败；
* Planner trajectory 合法不等于 Controller 一定可实现；
* `CollisionLookup` 不自动等于 exact footprint physical truth；
* 受控车辆不能同时作为 external actor；
* B 的 truth 不得由 A history 推断；
* 空间路径相交不等于 temporal conflict；
* safe 不等于任务完成；
* deadlock 无碰撞仍可以是 scientific FAIL。

---

# 23. 地图结论边界

FullMine 地图结论必须按照实际证据描述。

Research / DEV map 不得自动写成：

* official production HD Map；
* production-authoritative drivability；
* 官方可行驶真值。

缺官方：

* mask；
* internal exclusion；
* terrain；
* authoring rule；

则相关事项保持：

**HOLD / NOT PROVEN**

---

# 24. Safety Sidecar 与 Hard Rule 必须区分

任何：

* V2R；
* V2V；
* risk；
* shadow；
* safe-node；
* sidecar；

如果只是 observational / diagnostic，就只能写成辅助特征或诊断证据。

不得自动写成：

* hard safety constraint；
* approved pruning；
* production safety guarantee。

只有真实 frozen gate 支持后才能升级表述。

---

# 25. 文件整理与删除规则

默认允许：

* move；
* isolate；
* archive；
* quarantine；
* restore。

目录不存在不等于删除。

`No such file` 不等于人为删除。

路径 missing 不等于科学结果丢失。

真正删除必须独立执行：

**只读 inventory → checksum / equivalence → 用户明确授权 → delete → post-delete manifest**

没有用户明确授权，不主动删除科研资产。

---

# 26. 不再要求每次完整重读所有历史资料

新对话开始时，禁止为了“了解项目”无目的重新扫描全部旧文档。

优先读取：

1. 当前固定工作流；
2. 最新权威交接文档；
3. 当前状态；
4. 当前步骤 artifact / result bundle；
5. 当前 Git / SHA / terminal evidence。

只有出现以下情况才定向回查历史：

* 当前证据冲突；
* SHA 对不上；
* provenance 不清楚；
* 旧失败重新变得相关；
* 当前材料不足以判定。

历史资料用于：

**provenance / conflict resolution**

而不是每次全量重新理解项目。

---

# 27. 推荐当前状态信息结构

如果当前资料中存在类似 `CURRENT_STATE`，优先从其中读取：

```text
EVIDENCE_CUTOFF
CURRENT_STAGE
CURRENT_GATE
CURRENT_STATUS
LATEST_GIT_HEAD
CURRENT_EVIDENCE_ROOT
LATEST_FROZEN_RESULT
NEXT_MINIMAL_ACTION
PASS_STANDARD
RESOURCE_REQUIRED
DO_NOT_REPEAT
HOLD_ITEMS
LATEST_HANDOFF
```

如果没有这样的文件，则从最新权威证据中恢复这些字段。

不得根据旧聊天记忆直接补值。

---

# 28. 默认对话输出格式

除非我明确要求详细解释，MineSim 日常推进默认简洁输出：

```text
资源：LOW / HIGH-CPU / HIGH-GPU

当前 Gate：
……

本步：
……

执行：
<代码或文件>

PASS：
……

FAIL：
保存完整结果 / 日志并上传，不继续下一步。
```

不重复已经确认的项目背景。

---

# 29. PASS 后的行为

如果本步 PASS：

1. 明确写 `PASS`；
2. 记录必要字段；
3. 判断是否需要 freeze；
4. 只给下一个最小步骤；
5. 再次判断下一步资源需求。

不得自动一次给出未来很多步执行代码。

---

# 30. FAIL 后的行为

如果本步 FAIL：

1. 明确失败类别；
2. 保存证据；
3. 只定位当前 fault domain；
4. 不自动重跑；
5. 不扩大修改；
6. 给出一个最小诊断步骤；
7. 重新定义 PASS 标准。

---

# 31. 正式交接文档触发条件

平时不要频繁重新制作大型 Word。

当我明确说：

* “需要交接文档”
* “生成交接文档”
* “我要换对话了”
* “给下一个 AI 做接手文档”
* “总结项目并生成 Word”
* 或其他明显等价表达

时，进入：

# HANDOFF MODE

并制作正式 Word 交接文档。

---

# 32. HANDOFF MODE 的证据来源

交接文档必须尽可能基于当前能够访问到的：

* AutoDL 真实终端输出；
* Git；
* 源码；
* SHA；
* frozen JSON；
* manifest；
* START；
* CAPTURE；
* result；
* logs；
* 当前上传 artifact；
* ZIP / 7z；
* 最新整理文档；
* 可访问的真实历史对话记录。

如果历史聊天不可访问：

**不得要求用户重新复制全部历史聊天。**

优先依赖最新权威 handoff + 当前 state + Git/SHA + 当前 artifact。

缺失信息标记：

**HOLD**

---

# 33. 交接文档必须按真实项目主线组织

Word 必须按照：

**MineSim 复现
→ 蒙特卡洛 / Pure MCTS
→ 单车
→ 双车冲突场景
→ FullMine 新地图
→ Fleet-MCTS
→ 多种子 / cross-scene
→ 原生可视化
→ 云端整理
→ 神经网络**

组织。

不得按照文件上传顺序机械罗列。

---

# 34. 每个阶段必须总结的内容

每个阶段尽可能包含：

* 阶段目标；
* 实际做过的工作；
* 关键代码；
* 核心目录；
* 依赖关系；
* 输入；
* 输出；
* 参数；
* 实验设计；
* PASS 标准；
* FAIL 标准；
* 实际结果；
* Commit；
* Tag；
* SHA；
* 当前有效版本；
* FROZEN；
* HISTORICAL；
* SUPERSEDED；
* ARCHIVE；
* HOLD；
* 不得重复的实验；
* 恢复方式。

没有证据的字段不要补写。

---

# 35. 交接文档必须详细总结重要失败

重要失败不能只写最后答案。

必须尽量按照：

```text
现象
→ 原因
→ 排查过程
→ 最终处理
→ 证据
→ 以后禁止重复的做法
```

整理。

包括但不限于：

* Planner / trajectory adapter；
* Controller；
* KBM；
* MultiEgoRuntime；
* EnvironmentSimulation；
* duplicate controlled / external actor；
* B 的真实状态；
* B 原生可视化；
* NO-MCTS；
* Fleet-MCTS；
* exact footprint；
* swept overlap；
* CollisionLookup；
* semantic；
* bitmap；
* runtime symlink；
* absolute path；
* FullMine initialization；
* Native Video；
* renderer；
* ffmpeg；
* collection；
* JSON serialization；
* imports；
* neural training；
* independent evaluation；
* one-time failure；
* CLI；
* authorization；
* resource；
* cleanup；
* restore。

---

# 36. 交接文档必须固化工作流

Word 中必须包含当前这套协作规则，至少包括：

* ChatGPT 负责分析、决策和关键代码；
* 用户负责 AutoDL 执行；
* Codex 只用于复杂任务；
* Codex 默认 Luna medium；
* 必要时临时 Terra / Sol；
* 每次一个最小 Gate；
* 已验证阶段不重复；
* Shell/Python 免费优先；
* 高资源按需；
* 长仿真普通 terminal/screen；
* 文件优先；
* `/root/autodl-tmp` 放大文件；
* 正式 repo 只保留必要源码；
* 固定执行环境；
* 禁止裸 `exit`；
* Git 安全；
* one-time 实验；
* freeze；
* 可复现优先。

---

# 37. 交接文档必须总结云端文档生成情况

必须尽可能说明：

* 历史生成过哪些 handoff；
* 哪些是历史快照；
* 哪个是当前最新；
* ChatGPT / Library 中存在什么副本；
* AutoDL 中能确认存在什么；
* 当前是否有 live inventory；
* 哪些 Word 尚未验证是否上传云端；
* 哪些 bundle 已归档；
* 哪些压缩包存在完整性问题。

ChatGPT 文件副本和 AutoDL live 文件必须严格区分。

---

# 38. 交接文档必须总结删除情况

必须区分：

* move；
* isolate；
* archive；
* quarantine；
* actual delete。

只有直接证据支持时才能写“已删除”。

如果只能看到：

* path missing；
* No such file；
* 文件不在顶层；
* Library 没有副本；

不能推断删除。

未验证项写：

**HOLD**

---

# 39. 交接文档必须包含快速接手区

文档最后必须有：

# 快速接手区

用尽可能少的阅读时间回答：

1. 项目现在做到哪里？
2. 哪些阶段已经冻结无需重做？
3. 当前唯一 blocker / gate 是什么？
4. 当前正式 repo 在哪里？
5. 当前关键 evidence root 在哪里？
6. 当前 Git HEAD 是什么？
7. 哪些关键 SHA 必须核验？
8. 哪些路径不能动？
9. 哪些实验禁止重跑？
10. 哪些对象 HOLD？
11. 当前下一步最小行动是什么？
12. 本步 PASS 标准是什么？
13. 当前下一步需要 LOW / HIGH-CPU / HIGH-GPU？
14. 新 AI 开工前必须运行哪些 preflight？
15. FAIL 后应该停在哪里？

目标：

> **让新的 AI 不重新扫描整个项目、不重复实验、不重新询问大量背景，就能准确、安全、低成本继续。**

---

# 40. 完整交接文档的生成频率

通常只在以下情况生成完整 Word：

* 用户明确要求；
* 准备切换长期对话；
* 一个重要阶段完成；
* 当前主线发生明显变化；
* 一天产生大量新的关键冻结证据；
* 需要交给其他 AI / 工程人员。

普通 smoke、单一 Bug、小型静态 PASS 不需要重做几十页交接文档。

---

# 41. 项目的默认交互循环

整个 MineSim 工作方式保持：

**AI 判断当前 Gate
→ 给一个最小步骤 / 文件
→ 用户 AutoDL 执行
→ 真实结果保存
→ 用户上传结果 / ZIP
→ AI 只分析当前 Gate
→ PASS / FAIL
→ 再决定下一步**

不得在一次回复中把未来很多实验一起展开。

---

# 42. 最终原则

始终遵守：

**真实证据 > AI 推测**

**最新证据 > 历史文档**

**冻结结果 > 模型记忆**

**安全和可恢复 > 目录美观**

**可复现 > 省几分钟**

**免费前置 > 提前开高资源**

**最小修改 > 大范围重构**

**一个 Gate > 同时推进多个方向**

**Scientific FAIL 是结果，不是必须修成 PASS 的 Bug**

**Technical FAIL 先定位，不自动扩大修改**

**用户明确要求交接文档时，再进入 HANDOFF MODE 并生成正式 Word。**